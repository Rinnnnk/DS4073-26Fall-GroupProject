# NYC Rental Trade-offs — Module A

This standalone dashboard uses Census tract data to show where rents are higher, how geographic coverage changes with a renter's budget, and where rent levels and rent burden diverge. It contains seven charts across four rows.

## Open or rebuild

Open `Dashboard_A.html` in a browser for the offline dashboard. The budget slider, chart tooltips and map all work locally.

To rebuild, open `Dashboard_A.Rmd` in RStudio. Edit the `presenter_name` and `student_id` parameters at the top, then click **Knit**. From an R session with this folder as the working directory, the equivalent is:

```r
install.packages(c("data.table", "sf", "flexdashboard", "rmarkdown", "knitr",
                   "plotly", "leaflet", "htmlwidgets", "htmltools"))
rmarkdown::render("Dashboard_A.Rmd", encoding = "UTF-8",
                  params = list(presenter_name = "Your name", student_id = "Your student ID"))
```

Install the packages once. R Markdown also requires Pandoc, which RStudio provides. Keep the source directories next to the `.Rmd`. For an `sf` installation that uses a separate PROJ data directory, set `NYC_PROJ_DIR` to that directory before rendering.

## Code and data

| File | Purpose |
| --- | --- |
| `Dashboard_A.Rmd` | Loads the inputs and builds a single flexdashboard page. |
| `module_A/housing_analysis.R` | Defines each eligible sample, exact budget counts, citywide ranks and case calculations. |
| `module_A/visualizations.R` | Builds the seven R charts using Leaflet and Plotly. |
| `module_A/housing_page.Rmd` | Defines the chart layout, captions and methods. |
| `module_A/budget.js` | Updates the budget comparison in the browser using the values calculated in R. |
| `scripts/` | Contains the shared formatters and widget helpers from the group starter. |
| `data/tracts.csv` | Housing columns from the starter's 2,325-row prepared tract table. The team joined ACS tables B25064, B19013 and B25070 to NYC tract GEOIDs and treated special negative values as unavailable. |
| `data/tract-boundaries.geojson` | The starter's simplified 2020 NYC census tract boundaries for the offline map. |
| `data/acs_b25070_cases.csv` | Eleven published ACS B25070 count fields for the two case tracts, extracted by `GEO_ID` from the starter's ACS snapshot. The R code aggregates the original counts and reconciles them with the main tract table. |

Source tables are the [ACS 2020–2024 five-year release](https://www.census.gov/programs-surveys/acs/data/summary-file.2024.html), [B25064 median gross rent](https://api.census.gov/data/2024/acs/acs5/groups/B25064.html), [B19013 median household income](https://api.census.gov/data/2024/acs/acs5/groups/B19013.html) and [B25070 rent-to-income bands](https://api.census.gov/data/2024/acs/acs5/groups/B25070.html). Geometry comes from the starter's [NYC Department of City Planning tract boundaries](https://data.cityofnewyork.us/City-Government/2020-Census-Tracts/63ge-mke6).

## How to read the charts

- **A1:** Map colors use fixed dollar bands. Scatterplot positions show monthly gross rent versus annual household income. Borough colors are categorical. Open diamonds mark one or both ACS upper categories. Reported Spearman correlations use tracts below both upper categories.
- **A2:** Empirical step curves show how coverage grows across the budget range. The bars compare boroughs at the exact selected ceiling with a common percentage scale. Coverage counts tract medians at or below the budget. The denominator includes all published rent estimates in that borough. This measures historical geographic coverage of tract medians. Current listings and the number of rentable units need separate data.
- **A3:** The scatterplot shows point estimates and shades opposite citywide rank quarters. The signed bars use a zero baseline for the percentile gap and show four uncensored examples per direction. The two 100% stacked bars show ACS rent-to-income bands. They share a zero baseline for the 50%+ segment and for the combined 30%+ share.

The A3 sample requires a published rent estimate, a valid burden rate and at least 50 renter households with computable rent-to-income ratios. All summaries are descriptive, tract-level estimates. A's samples follow the variables needed for each question.

## Handoff to the group lead

The Housing page can be previewed as-is. To merge the source, use the four files in `module_A/` and add `data/acs_b25070_cases.csv`. The group can reuse its existing tract table, geometry and shared R helpers. After loading the shared data as `nyc`, source the two A `.R` files, compute `housing <- housing_data(nyc$tr)` and `housing_charts <- housing_widgets(nyc, housing)`, and set `housing_author` to the presenter's name and ID. Include `module_A/housing_page.Rmd` under the Housing heading as a knitr child. Copy the `.a-` styles from the standalone `dashboard.css` and set A's chart count to seven if the group template checks chart counts during rendering.
