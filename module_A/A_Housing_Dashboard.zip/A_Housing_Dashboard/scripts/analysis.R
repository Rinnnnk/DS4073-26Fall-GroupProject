# Shared definitions from the group dashboard, used by the standalone Housing page.
suppressPackageStartupMessages(library(data.table))
borough_order <- c("Bronx", "Brooklyn", "Manhattan", "Queens", "Staten Island")
boro_colors <- setNames(c("#9A5A3B", "#217B78", "#284B75", "#7261A1", "#9C761E"), borough_order)
show_n <- function(x) formatC(x, digits = 0, format = "f", big.mark = ",")
show_dollar <- function(x) paste0("$", show_n(x))
is_top_coded <- function(x) x == 3501
show_rent <- function(x) ifelse(is_top_coded(x), "$3,500+", show_dollar(x))
show_pct <- function(x) sprintf("%.1f%%", 100 * x)
pct_rank <- function(x) 100 * (frank(x, ties.method = "average") - 1) / (length(x) - 1)
